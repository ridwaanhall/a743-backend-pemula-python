# Dicoding: Belajar Back-End Pemula dengan Python

[OpenShop](https://github.com/ridwaanhall/a743-backend-pemula-python/tree/open-shop)
